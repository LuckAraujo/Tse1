# Tse1
Forca 
 Fazer Parte do Botão "FDS"
 Pontuação
 e adiocinar mais palavras no banco de dados
